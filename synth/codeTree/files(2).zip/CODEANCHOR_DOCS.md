# CodeAnchor 完整文档

> 把文档描述绑定到具体代码片段的哈希。代码一变哈希失效，AI 在干活前就知道哪些摘要在撒谎。

---

## 目录

1. [核心思路](#核心思路)
2. [文件结构](#文件结构)
3. [快速开始](#快速开始)
4. [配置参考](#配置参考)
5. [完整代码](#完整代码)
   - [anchor_engine.py](#anchor_enginepy)
   - [agent_tools.py](#agent_toolspy)
   - [patrol.py](#patrolpy)
   - [deep_drift.py](#deep_driftpy)
6. [接入你的 Agent](#接入你的-agent)
7. [大幅改动后如何恢复](#大幅改动后如何恢复)
8. [CLAUDE.md 模板](#claudemd-模板)
9. [自动化配置](#自动化配置)

---

## 核心思路

```
代码树分析器生成摘要
        ↓
create_anchor()  →  把摘要和代码片段的 SHA-1 哈希绑定
        ↓
.code_anchors.json  ←→  随代码一起提交到 git

每次 session：
check_drift()  →  发现 stale/missing 锚点
        ↓
patrol.py（便宜 LLM）  →  自动更新摘要
        ↓
智能 AI 开始工作，携带最新摘要作为上下文
        ↓
改完代码后：
refresh_anchor()  →  更新哈希
sync_doc_file()   →  写回文档里的 @anchor tag

大幅改动后：
deep_drift.py  →  模糊查找消失的符号 + AI 叙述整体变更
```

### 锚点格式

```
## 用户认证模块
<!-- @anchor{id="auth.validate" file="src/auth/service.py" symbol="AuthService.validate" hash="a3f2c1d8"} -->
负责验证 Bearer Token，失败超过3次后锁定账户。
```

哈希稳定性：计算前去掉空行并 strip 尾部空格，加注释或调整缩进不会触发误报。

---

## 文件结构

```
your_project/
├── code_anchor/
│   ├── __init__.py
│   ├── anchor_engine.py    # 核心：哈希绑定、drift 检测
│   └── agent_tools.py      # Agent tool registry（JSON schema）
├── patrol.py               # 定期巡查：便宜 LLM 更新摘要
├── deep_drift.py           # 大幅改动后的恢复分析
├── .code_anchors.json      # 锚点数据库（提交到 git）
└── CLAUDE.md               # 含 @anchor tag 的文档
```

---

## 快速开始

### 1. 安装依赖

```bash
# 最小依赖（仅 Python 标准库 + 你已有的分析器）
# 无需额外安装

# 如果用 Anthropic API：
pip install anthropic

# 如果用 OpenAI / DeepSeek：
pip install openai

# 如果用本地 Ollama（推荐，零成本）：
# 直接调用 localhost:11434，无需额外依赖
ollama pull qwen2.5-coder:7b
```

### 2. 建立第一批锚点

```python
from code_anchor import create_anchor

# 绑定到函数级别（最精准）
create_anchor(
    anchor_id="auth.validate",
    file="src/auth/service.py",
    symbol="AuthService.validate",
    description="验证 Bearer Token，失败3次锁定",
    root="/your/project"
)

# 或者配合你的代码树分析器批量建立
for module in code_tree.modules:
    create_anchor(
        anchor_id=module.dot_path,
        file=module.file,
        symbol=module.symbol,
        description=module.summary,
        root=project_root
    )
```

### 3. 把 tag 粘贴进文档

`create_anchor()` 返回一个 tag，粘贴到对应描述旁：

```markdown
## 用户认证模块
<!-- @anchor{id="auth.validate" file="src/auth/service.py" symbol="AuthService.validate" hash="a3f2c1d8"} -->
验证 Bearer Token，失败3次锁定账户。
```

### 4. 每次 session 开始前检查

```python
from code_anchor import check_drift

result = check_drift(root="/your/project")
print(result["summary"])
# Drift check: 5 ok, 2 stale, 1 missing
```

### 5. 定期巡查（自动更新摘要）

```bash
# 本地 Ollama（零成本）
python patrol.py --root . --doc CLAUDE.md

# DeepSeek（极便宜）
DEEPSEEK_API_KEY=xxx python patrol.py --model deepseek/deepseek-chat

# 预览不写入
python patrol.py --dry-run
```

---

## 配置参考

### 模型选择

| 场景 | 推荐模型 | 成本 | 说明 |
|------|---------|------|------|
| 日常巡查 | `ollama/qwen2.5-coder:7b` | 零 | 本地运行，够用 |
| 日常巡查（云端） | `deepseek/deepseek-chat` | 极低 | 约 $0.001/次 |
| 大幅改动叙述 | `anthropic/claude-haiku-4-5` | 低 | 需要更强理解力 |
| 大幅改动叙述 | `openai/gpt-4o-mini` | 低 | 备选 |

```python
# 模型 spec 格式：
"ollama/qwen2.5-coder:7b"           # 本地 Ollama
"anthropic/claude-haiku-4-5"        # Anthropic API
"openai/gpt-4o-mini"                # OpenAI API
"deepseek/deepseek-chat"            # DeepSeek API
"openai-compat/your-model"          # 任意 OpenAI 兼容接口（读 OPENAI_BASE_URL）
```

### 环境变量

```bash
ANTHROPIC_API_KEY=sk-ant-...
OPENAI_API_KEY=sk-...
DEEPSEEK_API_KEY=sk-...
OPENAI_BASE_URL=https://your-custom-endpoint/v1   # openai-compat 模式用
```

### 哈希粒度

| 粒度 | 参数 | 适用场景 |
|------|------|---------|
| 函数/方法 | `symbol="ClassName.method"` | 推荐，精准度最高 |
| 整个类 | `symbol="ClassName"` | 类变动频繁时 |
| 行范围 | `line_start=10, line_end=25` | 配置块、常量区 |
| 整个文件 | 不传 symbol | 简单模块 |

---

## 完整代码

### anchor_engine.py

```python
"""
CodeAnchor Engine
-----------------
Binds documentation descriptions to specific code fragments via hash.
When code changes, anchors become stale — agents detect drift before acting.

Anchor format (embedded in any text/markdown/json doc):
    @anchor{id="auth.login" file="src/auth/login.py" symbol="LoginHandler.authenticate" hash="a3f2c1d8"}

Granularity options:
    - file-level:    hash entire file
    - symbol-level:  hash a specific function/class (via AST)
    - line-range:    hash lines N-M
"""

import ast
import hashlib
import json
import re
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Optional


@dataclass
class Anchor:
    id: str
    file: str
    symbol: Optional[str] = None
    line_start: Optional[int] = None
    line_end: Optional[int] = None
    hash: str = ""
    description: str = ""

    def to_tag(self) -> str:
        parts = [f'id="{self.id}"', f'file="{self.file}"']
        if self.symbol:
            parts.append(f'symbol="{self.symbol}"')
        if self.line_start is not None:
            parts.append(f'lines="{self.line_start}-{self.line_end}"')
        parts.append(f'hash="{self.hash}"')
        return "@anchor{" + " ".join(parts) + "}"


@dataclass
class DriftReport:
    anchor_id: str
    file: str
    symbol: Optional[str]
    status: str
    stored_hash: str
    current_hash: str
    description: str = ""

    @property
    def is_ok(self) -> bool:
        return self.status == "ok"


def _short_hash(content: str) -> str:
    lines = [l.rstrip() for l in content.splitlines() if l.strip()]
    normalized = "\n".join(lines)
    return hashlib.sha1(normalized.encode()).hexdigest()[:8]


def _extract_symbol_source(file_path: Path, symbol: str) -> Optional[str]:
    try:
        source = file_path.read_text(encoding="utf-8")
        tree = ast.parse(source)
    except (SyntaxError, OSError):
        return None
    lines = source.splitlines()
    parts = symbol.split(".", 1)
    top_name = parts[0]
    method_name = parts[1] if len(parts) > 1 else None
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
            if node.name == top_name:
                if method_name is None:
                    end = node.end_lineno
                    return "\n".join(lines[node.lineno - 1 : end])
                elif isinstance(node, ast.ClassDef):
                    for child in ast.walk(node):
                        if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                            if child.name == method_name:
                                end = child.end_lineno
                                return "\n".join(lines[child.lineno - 1 : end])
    return None


def _extract_lines_source(file_path: Path, start: int, end: int) -> Optional[str]:
    try:
        lines = file_path.read_text(encoding="utf-8").splitlines()
        return "\n".join(lines[start - 1 : end])
    except OSError:
        return None


def compute_hash(file, symbol=None, line_start=None, line_end=None, root=Path(".")) -> tuple:
    p = root / file
    if not p.exists():
        return "", "missing_file"
    if symbol:
        src = _extract_symbol_source(p, symbol)
        if src is None:
            return "", "missing_symbol"
        return _short_hash(src), "ok"
    if line_start is not None:
        src = _extract_lines_source(p, line_start, line_end or line_start)
        if src is None:
            return "", "missing_file"
        return _short_hash(src), "ok"
    return _short_hash(p.read_text(encoding="utf-8")), "ok"


ANCHOR_DB = ".code_anchors.json"

def _load_db(root: Path) -> dict:
    db_path = root / ANCHOR_DB
    if db_path.exists():
        return json.loads(db_path.read_text())
    return {}

def _save_db(root: Path, db: dict):
    (root / ANCHOR_DB).write_text(json.dumps(db, indent=2, ensure_ascii=False))


_TAG_RE = re.compile(r'@anchor\{([^}]+)\}')
_ATTR_RE = re.compile(r'(\w+)="([^"]*)"')

def parse_anchors_from_text(text: str) -> list:
    anchors = []
    for m in _TAG_RE.finditer(text):
        attrs = dict(_ATTR_RE.findall(m.group(1)))
        lines_raw = attrs.get("lines", "")
        ls = le = None
        if "-" in lines_raw:
            ls_s, le_s = lines_raw.split("-", 1)
            ls, le = int(ls_s), int(le_s)
        anchors.append(Anchor(
            id=attrs.get("id", ""), file=attrs.get("file", ""),
            symbol=attrs.get("symbol") or None,
            line_start=ls, line_end=le, hash=attrs.get("hash", ""),
            description=attrs.get("desc", ""),
        ))
    return anchors


def create_anchor(anchor_id, file, symbol=None, line_start=None,
                  line_end=None, description="", root=".") -> dict:
    rp = Path(root)
    h, status = compute_hash(file, symbol, line_start, line_end, rp)
    if status != "ok":
        return {"status": status, "anchor_id": anchor_id, "tag": None, "hash": None}
    anchor = Anchor(id=anchor_id, file=file, symbol=symbol,
                    line_start=line_start, line_end=line_end, hash=h, description=description)
    db = _load_db(rp)
    db[anchor_id] = asdict(anchor)
    _save_db(rp, db)
    return {"status": "created", "anchor_id": anchor_id, "hash": h,
            "tag": anchor.to_tag(),
            "instruction": f"Paste into your doc:\n  {anchor.to_tag()}"}


def check_drift(anchor_ids=None, doc_text=None, root=".") -> dict:
    rp = Path(root)
    db = _load_db(rp)
    to_check = {}
    if doc_text:
        for a in parse_anchors_from_text(doc_text):
            if a.id:
                to_check[a.id] = a
    if anchor_ids:
        for aid in anchor_ids:
            if aid in db:
                to_check[aid] = Anchor(**db[aid])
    elif not doc_text:
        for aid, data in db.items():
            to_check[aid] = Anchor(**data)
    for aid, a in to_check.items():
        if aid in db and not a.hash:
            a.hash = db[aid]["hash"]
    reports = []
    for aid, anchor in to_check.items():
        current_hash, status = compute_hash(anchor.file, anchor.symbol,
                                            anchor.line_start, anchor.line_end, rp)
        if status != "ok":
            drift_status = status
        elif current_hash != anchor.hash:
            drift_status = "stale"
        else:
            drift_status = "ok"
        reports.append(DriftReport(aid, anchor.file, anchor.symbol, drift_status,
                                   anchor.hash, current_hash, anchor.description))
    stale = [r for r in reports if r.status == "stale"]
    missing = [r for r in reports if r.status in ("missing_file", "missing_symbol")]
    ok = [r for r in reports if r.is_ok]
    def fmt(r):
        return {"anchor_id": r.anchor_id, "file": r.file, "symbol": r.symbol,
                "status": r.status, "stored_hash": r.stored_hash,
                "current_hash": r.current_hash, "description": r.description}
    lines = [f"Drift check: {len(ok)} ok, {len(stale)} stale, {len(missing)} missing"]
    if stale:
        lines.append("\nSTALE:")
        for r in stale:
            sym = f"::{r.symbol}" if r.symbol else ""
            lines.append(f"  ⚠ [{r.anchor_id}] {r.file}{sym}  {r.stored_hash} → {r.current_hash}")
    if missing:
        lines.append("\nMISSING:")
        for r in missing:
            lines.append(f"  ✗ [{r.anchor_id}] {r.file} ({r.status})")
    return {"stale": [fmt(r) for r in stale], "missing": [fmt(r) for r in missing],
            "ok": [fmt(r) for r in ok], "all_valid": not stale and not missing,
            "summary": "\n".join(lines)}


def refresh_anchor(anchor_id, root=".") -> dict:
    rp = Path(root)
    db = _load_db(rp)
    if anchor_id not in db:
        return {"status": "not_found", "anchor_id": anchor_id}
    anchor = Anchor(**db[anchor_id])
    old_hash = anchor.hash
    new_hash, status = compute_hash(anchor.file, anchor.symbol,
                                    anchor.line_start, anchor.line_end, rp)
    if status != "ok":
        return {"status": status, "anchor_id": anchor_id, "old_hash": old_hash}
    anchor.hash = new_hash
    db[anchor_id] = asdict(anchor)
    _save_db(rp, db)
    return {"status": "refreshed", "anchor_id": anchor_id, "old_hash": old_hash,
            "new_hash": new_hash, "changed": old_hash != new_hash, "tag": anchor.to_tag()}


def list_anchors(root=".") -> dict:
    rp = Path(root)
    db = _load_db(rp)
    result = []
    for aid, data in db.items():
        a = Anchor(**data)
        h, status = compute_hash(a.file, a.symbol, a.line_start, a.line_end, rp)
        drift = "ok" if (status == "ok" and h == a.hash) else status if status != "ok" else "stale"
        result.append({"anchor_id": aid, "file": a.file, "symbol": a.symbol,
                       "hash": a.hash, "drift": drift, "description": a.description})
    return {"anchors": result, "total": len(result)}
```

---

### agent_tools.py

```python
"""
Agent Tool Registry for CodeAnchor
Compatible with Anthropic tool_use and OpenAI function_calling.
"""
from code_anchor.anchor_engine import create_anchor, check_drift, refresh_anchor, list_anchors

TOOL_DEFINITIONS = [
    {
        "name": "create_anchor",
        "description": (
            "Bind a documentation description to a specific code fragment. "
            "Returns an @anchor tag to paste into the doc. "
            "Use when writing or updating documentation."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "anchor_id": {"type": "string", "description": "Dot-path name e.g. 'auth.login.validate'"},
                "file": {"type": "string", "description": "Relative path to source file"},
                "symbol": {"type": "string", "description": "'ClassName.method' or 'function_name'"},
                "line_start": {"type": "integer"},
                "line_end": {"type": "integer"},
                "description": {"type": "string", "description": "Human-readable label for reports"},
                "root": {"type": "string", "description": "Project root, default '.'"},
            },
            "required": ["anchor_id", "file"],
        },
    },
    {
        "name": "check_drift",
        "description": (
            "Check which anchors have drifted. "
            "CALL THIS AT THE START OF EVERY SESSION. "
            "Stale anchors mean documentation may be wrong."
        ),
        "input_schema": {
            "type": "object",
            "properties": {
                "anchor_ids": {"type": "array", "items": {"type": "string"}},
                "doc_text": {"type": "string", "description": "Raw doc text with @anchor tags"},
                "root": {"type": "string"},
            },
            "required": [],
        },
    },
    {
        "name": "refresh_anchor",
        "description": "After modifying code, recompute hash. Call AFTER completing code changes.",
        "input_schema": {
            "type": "object",
            "properties": {
                "anchor_id": {"type": "string"},
                "root": {"type": "string"},
            },
            "required": ["anchor_id"],
        },
    },
    {
        "name": "list_anchors",
        "description": "List all registered anchors with drift status.",
        "input_schema": {
            "type": "object",
            "properties": {"root": {"type": "string"}},
            "required": [],
        },
    },
]

_TOOL_MAP = {
    "create_anchor": create_anchor,
    "check_drift": check_drift,
    "refresh_anchor": refresh_anchor,
    "list_anchors": list_anchors,
}

def handle_tool_call(tool_name: str, tool_args: dict) -> dict:
    fn = _TOOL_MAP.get(tool_name)
    if fn is None:
        return {"error": f"Unknown tool: {tool_name}"}
    try:
        return fn(**tool_args)
    except Exception as e:
        return {"error": str(e), "tool": tool_name}
```

---

### patrol.py

见项目根目录 `patrol.py`（完整源码已交付）。

**关键配置项：**

```python
# patrol.py 顶部常量（可按需修改）

PATROL_PROMPT = """\
You are a documentation patrol bot...
...Max {max_words} words.
"""
# 可以在这里调整 prompt 风格，比如要求中文输出：
# 在 prompt 末尾加：Reply in Chinese.
```

**命令行用法：**

```bash
# 基础用法
python patrol.py --root . --doc CLAUDE.md

# 指定模型
python patrol.py --model anthropic/claude-haiku-4-5 --doc CLAUDE.md

# 多个文档文件
python patrol.py --doc CLAUDE.md --doc docs/architecture.md

# 预览模式（不写入任何文件）
python patrol.py --dry-run --verbose

# 指定多个文档
python patrol.py --doc CLAUDE.md --doc docs/modules.md --root /your/project
```

---

### deep_drift.py

见项目根目录 `deep_drift.py`（完整源码已交付）。

**命令行用法：**

```bash
# 对比最新未提交的变化
python deep_drift.py --root . --out drift_report.md

# 对比最近3个commit
python deep_drift.py --since HEAD~3 --out drift_report.md

# 对比某个分支
python deep_drift.py --since main --model ollama/qwen2.5-coder:7b

# 生成带 AI 叙述的报告（推荐大重构后使用）
python deep_drift.py --since HEAD~10 --model anthropic/claude-haiku-4-5 --out drift_report.md
```

---

## 接入你的 Agent

```python
from code_anchor import TOOL_DEFINITIONS, handle_tool_call
import anthropic

client = anthropic.Anthropic()

def run_agent_session(user_message: str, project_root: str):
    # Agent 带上工具定义
    response = client.messages.create(
        model="claude-sonnet-4-20250514",
        max_tokens=4096,
        tools=TOOL_DEFINITIONS,
        system="""
        ## 强制工作流

        1. 每次 session 开始，首先调用 check_drift()
        2. 如果有 stale 锚点，先报告哪些摘要可能过期，再继续工作
        3. 完成代码修改后，调用 refresh_anchor() 更新对应锚点
        4. 写新功能文档时，调用 create_anchor() 建立绑定

        project_root: {root}
        """.format(root=project_root),
        messages=[{"role": "user", "content": user_message}],
    )

    # 处理工具调用循环
    while response.stop_reason == "tool_use":
        tool_results = []
        for block in response.content:
            if block.type == "tool_use":
                result = handle_tool_call(block.name, block.input)
                tool_results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": json.dumps(result, ensure_ascii=False),
                })

        response = client.messages.create(
            model="claude-sonnet-4-20250514",
            max_tokens=4096,
            tools=TOOL_DEFINITIONS,
            messages=[
                {"role": "user", "content": user_message},
                {"role": "assistant", "content": response.content},
                {"role": "user", "content": tool_results},
            ],
        )

    return response.content[0].text
```

---

## 大幅改动后如何恢复

这是最核心的问题。三种情况，三种处理方式：

### 情况1：函数内部逻辑大改（符号还在）

```
状态：stale（哈希不匹配）
信息：diff 清晰可见
处理：patrol.py 自动搞定
```

patrol 从 git 提取 diff，便宜 LLM 判断摘要是否需要更新，直接写回。

### 情况2：函数/文件被删除或重命名

```
状态：missing_file 或 missing_symbol
信息：符号/文件不存在
处理：deep_drift.py 模糊查找 + 人工确认
```

```bash
python deep_drift.py --since HEAD~1 --out drift_report.md
```

`deep_drift.py` 做的事：

1. AST 扫描整个项目所有函数/类
2. 用 `SequenceMatcher` 对消失的符号名做模糊匹配
3. 用 git 拿到删除前的原始代码
4. 给出候选列表（相似度排序）
5. 生成 Markdown 报告，每个 missing 锚点附带建议重绑命令

报告示例：
```markdown
### ✗ Missing（文件或符号已消失）

#### `auth.validate`
- **原路径**: `src/auth/service.py` :: `AuthService.validate`
- **原描述**: 验证 Bearer Token
- **模糊匹配候选**:
  - `src/auth/jwt_service.py::JWTService.verify_token` (相似度 0.82)
  - `src/auth/service.py::AuthService.check_token` (相似度 0.71)

🔴 **[auth.validate]** 建议重绑：
  create_anchor('auth.validate', 'src/auth/jwt_service.py', symbol='JWTService.verify_token')
```

确认候选正确后，一行命令重新绑定：

```python
from code_anchor import create_anchor
create_anchor('auth.validate', 'src/auth/jwt_service.py',
              symbol='JWTService.verify_token',
              description='验证 JWT Token 合法性',
              root='/your/project')
```

### 情况3：大规模重构（多文件联动）

```
状态：大量 stale + missing 混合
处理：deep_drift + AI 叙述，理解整体变更方向
```

```bash
# 用更强的模型生成整体叙述
python deep_drift.py \
  --since HEAD~20 \
  --model anthropic/claude-haiku-4-5 \
  --out drift_report.md
```

AI 叙述帮你理解："这次重构把认证模块从单体拆成了 JWT + OAuth 两个服务，原来的 AuthService.validate 的功能分散到了三个新函数..."

然后按报告里的行动清单逐条处理：
- 🔴 高优先级：missing 锚点（功能去哪了？）
- 🟡 中优先级：stale 锚点（描述要不要改？）

### 能完全自动恢复吗？

| 改动类型 | 自动程度 | 需要人工吗 |
|---------|---------|---------|
| 函数内部小改 | 全自动（patrol） | 不需要 |
| 函数内部大改 | 全自动（patrol + git diff） | 不需要 |
| 函数重命名 | 半自动（deep_drift 给候选） | 确认候选即可 |
| 文件重命名 | 半自动 | 确认候选即可 |
| 功能拆分/合并 | 需要叙述辅助 | 需要看报告决策 |
| 功能删除 | 自动检测，无法重建 | 需要决定删锚点 |

**结论**：文件/函数存在的情况下几乎全自动。功能彻底消失无法"凭空找回"——但工具会告诉你"它消失了"，而不是让你拿着过期摘要继续干活。

---

## CLAUDE.md 模板

```markdown
# 项目名称

## 强制工作流（AI 必须遵守）

1. 每次 session 开始，调用 check_drift()
2. 有 stale → 先告知用户，再继续
3. 改完代码 → 调用 refresh_anchor()
4. 大重构后 → 运行 python deep_drift.py

## 架构总览

### 认证模块
<!-- @anchor{id="auth.validate" file="src/auth/service.py" symbol="AuthService.validate" hash="a3f2c1d8"} -->
验证 Bearer Token，失败3次锁定账户。调用链：API Gateway → AuthMiddleware → AuthService.validate

### 数据库层
<!-- @anchor{id="db.session" file="src/db/session.py" symbol="get_session" hash="b2e4f9a1"} -->
SQLAlchemy session 工厂，使用连接池，超时30秒自动回收。

## 编码规范

- 禁止直接 import db，通过 get_session() 获取连接
- 所有外部 API 调用必须有超时设置
- 新增模块后调用 create_anchor() 建立绑定
```

---

## 自动化配置

### pre-commit hook（防止带过期锚点提交）

`.git/hooks/pre-commit`：

```bash
#!/bin/bash
result=$(python -c "
from code_anchor import check_drift
import json
r = check_drift()
if not r['all_valid']:
    print(r['summary'])
    exit(1)
" 2>&1)

if [ $? -ne 0 ]; then
    echo "⚠ CodeAnchor: stale anchors detected. Run patrol.py first."
    echo "$result"
    exit 1
fi
```

```bash
chmod +x .git/hooks/pre-commit
```

### cron 定时巡查

```bash
# 每天早上9点，有 git 变化才触发
0 9 * * 1-5 cd /your/project && git diff --quiet HEAD || python patrol.py --doc CLAUDE.md >> .anchor_patrol.log 2>&1
```

### GitHub Actions

`.github/workflows/anchor-patrol.yml`：

```yaml
name: Anchor Patrol

on:
  push:
    branches: [main]
  schedule:
    - cron: '0 9 * * 1'  # 每周一早上

jobs:
  patrol:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v4
        with:
          python-version: '3.11'
      - run: pip install anthropic
      - name: Run patrol
        env:
          ANTHROPIC_API_KEY: ${{ secrets.ANTHROPIC_API_KEY }}
        run: |
          python patrol.py \
            --model anthropic/claude-haiku-4-5 \
            --doc CLAUDE.md \
            --root .
      - name: Commit updated anchors
        run: |
          git config user.name "Anchor Bot"
          git config user.email "bot@example.com"
          git add .code_anchors.json CLAUDE.md
          git diff --staged --quiet || git commit -m "chore: auto-refresh anchors"
          git push
```
