"""
Deep Drift Analyzer
--------------------
专门处理大幅度增删改之后的"找回"问题。

普通 check_drift() 对每个锚点独立检查 → 适合日常小改动
deep_drift_report() 做全局分析 → 适合大重构之后

核心能力：
1. 找出所有 stale/missing 锚点，并附上具体 diff
2. 用智能 AI（一次调用）生成跨文件的变更叙述
3. 对 missing 锚点尝试"模糊匹配"——在现有代码里找最像原来的东西
4. 输出 Markdown 报告，直接可以粘贴进 CLAUDE.md
"""

import ast
import difflib
import json
import subprocess
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

sys.path.insert(0, str(Path(__file__).parent))
from code_anchor.anchor_engine import (
    Anchor, check_drift, compute_hash, _load_db, _save_db,
    _extract_symbol_source,
)


# ─────────────────────────────────────────────
# Git helpers
# ─────────────────────────────────────────────

def git_diff_file(file: str, root: str, since: str = "HEAD") -> Optional[str]:
    """获取单文件相对于某个 commit 的 diff。"""
    try:
        r = subprocess.run(
            ["git", "diff", since, "--", file],
            cwd=root, capture_output=True, text=True, timeout=15
        )
        return r.stdout.strip() or None
    except Exception:
        return None


def git_log_files(root: str, since: str = "HEAD~1") -> list[str]:
    """获取自某个 commit 以来变动过的文件列表。"""
    try:
        r = subprocess.run(
            ["git", "diff", "--name-only", since],
            cwd=root, capture_output=True, text=True, timeout=10
        )
        return [f.strip() for f in r.stdout.splitlines() if f.strip()]
    except Exception:
        return []


def git_show_deleted(file: str, root: str) -> Optional[str]:
    """获取已删除文件在最后一个 commit 时的内容。"""
    try:
        r = subprocess.run(
            ["git", "show", f"HEAD:{file}"],
            cwd=root, capture_output=True, text=True, timeout=10
        )
        if r.returncode == 0:
            return r.stdout
        return None
    except Exception:
        return None


# ─────────────────────────────────────────────
# Fuzzy symbol finder
# ─────────────────────────────────────────────

def _list_all_symbols(root: Path, extensions: tuple = (".py",)) -> list[dict]:
    """遍历项目，提取所有 Python 函数/类名及其位置。"""
    symbols = []
    for p in root.rglob("*"):
        if p.suffix not in extensions or ".git" in p.parts:
            continue
        try:
            src = p.read_text(encoding="utf-8")
            tree = ast.parse(src)
        except Exception:
            continue
        rel = str(p.relative_to(root))
        for node in ast.walk(tree):
            if isinstance(node, ast.ClassDef):
                symbols.append({"file": rel, "symbol": node.name, "type": "class", "line": node.lineno})
                for child in ast.walk(node):
                    if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        symbols.append({
                            "file": rel,
                            "symbol": f"{node.name}.{child.name}",
                            "type": "method",
                            "line": child.lineno,
                        })
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if not any(isinstance(p, ast.ClassDef) for p in ast.walk(tree) if hasattr(p, 'body') and node in getattr(p, 'body', [])):
                    symbols.append({"file": rel, "symbol": node.name, "type": "function", "line": node.lineno})
    return symbols


def fuzzy_find_symbol(original_symbol: str, original_file: str, root: str) -> list[dict]:
    """
    当锚点的 symbol 消失后，在整个项目里找最相似的候选。
    返回按相似度排序的候选列表（最多5个）。
    """
    rp = Path(root)
    all_symbols = _list_all_symbols(rp)

    # 用 SequenceMatcher 对 symbol 名字做模糊匹配
    scored = []
    for s in all_symbols:
        name_score = difflib.SequenceMatcher(None, original_symbol, s["symbol"]).ratio()
        # 同目录/同文件加分
        file_bonus = 0.15 if Path(s["file"]).parent == Path(original_file).parent else 0
        scored.append((name_score + file_bonus, s))

    scored.sort(key=lambda x: x[0], reverse=True)
    return [
        {**s, "similarity": round(score, 2)}
        for score, s in scored[:5]
        if score > 0.4
    ]


# ─────────────────────────────────────────────
# Deep drift report
# ─────────────────────────────────────────────

@dataclass
class AnchorDriftDetail:
    anchor_id: str
    file: str
    symbol: Optional[str]
    description: str
    status: str           # "stale" | "missing_file" | "missing_symbol"
    diff: Optional[str]   # git diff 内容
    candidates: list      # fuzzy match 候选（仅 missing 时）
    old_source: Optional[str]  # 删除前的代码（仅 missing 时）


def deep_drift_report(
    root: str = ".",
    since: str = "HEAD",
    llm_model: Optional[str] = None,   # 如果提供，用 AI 生成叙述
    output_md: Optional[str] = None,   # 输出 Markdown 报告路径
) -> dict:
    """
    大幅改动后的全局漂移分析。

    Args:
        root:       项目根目录
        since:      对比的 git ref，默认 HEAD（未提交的变化）
                    用 "HEAD~3" 可以看最近3个commit的变动
        llm_model:  可选，用于生成叙述的模型（格式同 patrol.py）
        output_md:  可选，输出 Markdown 报告路径

    Returns:
        完整分析报告 dict，含：
        - stale_details:    stale 锚点的详细 diff
        - missing_details:  missing 锚点 + fuzzy 候选
        - narrative:        AI 生成的整体变更叙述（若提供 llm_model）
        - action_items:     建议的下一步操作列表
        - markdown:         完整 Markdown 报告字符串
    """
    rp = Path(root)
    db = _load_db(rp)

    print(f"\n🔬 Deep drift analysis (since {since})...")

    # Step 1: 基础 drift 检测
    drift = check_drift(root=root)
    stale_items = drift["stale"]
    missing_items = drift["missing"]

    print(f"   Found {len(stale_items)} stale, {len(missing_items)} missing")

    # Step 2: 丰富每个 stale 锚点的信息
    stale_details: list[AnchorDriftDetail] = []
    for item in stale_items:
        aid = item["anchor_id"]
        anchor = Anchor(**db[aid]) if aid in db else None
        if not anchor:
            continue
        diff_text = git_diff_file(anchor.file, root, since)
        stale_details.append(AnchorDriftDetail(
            anchor_id=aid,
            file=anchor.file,
            symbol=anchor.symbol,
            description=anchor.description,
            status="stale",
            diff=diff_text,
            candidates=[],
            old_source=None,
        ))

    # Step 3: 丰富 missing 锚点 — fuzzy 找候选
    missing_details: list[AnchorDriftDetail] = []
    for item in missing_items:
        aid = item["anchor_id"]
        anchor = Anchor(**db[aid]) if aid in db else None
        if not anchor:
            continue

        candidates = []
        old_source = None

        if anchor.symbol:
            # 符号消失了 → 模糊找
            candidates = fuzzy_find_symbol(anchor.symbol, anchor.file, root)
            # 尝试从 git 拿旧代码
            old_content = git_show_deleted(anchor.file, root)
            if old_content:
                lines = old_content.splitlines()
                # 简单搜索 symbol 名字所在行
                for i, line in enumerate(lines):
                    if f"def {anchor.symbol.split('.')[-1]}" in line or f"class {anchor.symbol.split('.')[-1]}" in line:
                        end = min(i + 30, len(lines))
                        old_source = "\n".join(lines[i:end])
                        break
        else:
            # 整个文件消失了
            old_source = git_show_deleted(anchor.file, root)
            if not old_source:
                old_source = "(file content not recoverable from git)"

        diff_text = git_diff_file(anchor.file, root, since)

        missing_details.append(AnchorDriftDetail(
            anchor_id=aid,
            file=anchor.file,
            symbol=anchor.symbol,
            description=anchor.description,
            status=item["status"],
            diff=diff_text,
            candidates=candidates,
            old_source=old_source,
        ))

    # Step 4: 可选 — AI 生成整体叙述
    narrative = ""
    if llm_model and (stale_details or missing_details):
        narrative = _generate_narrative(stale_details, missing_details, llm_model, root, since)

    # Step 5: 生成 action items
    action_items = _build_action_items(stale_details, missing_details)

    # Step 6: 生成 Markdown 报告
    md = _render_markdown(stale_details, missing_details, narrative, action_items, since)

    if output_md:
        Path(output_md).write_text(md, encoding="utf-8")
        print(f"   📄 Report written to {output_md}")

    print(f"   ✅ Deep analysis done\n")

    return {
        "stale_details": [vars(d) for d in stale_details],
        "missing_details": [vars(d) for d in missing_details],
        "narrative": narrative,
        "action_items": action_items,
        "markdown": md,
        "changed_files": git_log_files(root, since),
    }


# ─────────────────────────────────────────────
# AI narrative generation
# ─────────────────────────────────────────────

_NARRATIVE_PROMPT = """\
You are a senior engineer reviewing a large refactor. Below is a summary of
documentation anchors that have drifted since the last stable state.

## Stale anchors (code changed)
{stale_section}

## Missing anchors (file/symbol deleted or renamed)
{missing_section}

## Changed files
{changed_files}

Write a concise technical narrative (3-5 paragraphs) that:
1. Summarises what the refactor appears to have done at a high level
2. Identifies which architectural areas were most affected
3. For each missing anchor, states your best guess about where the functionality moved
4. Lists the highest-risk areas where the documentation is most likely wrong

Write in plain English. Be direct. No bullet points in the narrative itself."""


def _generate_narrative(
    stale: list[AnchorDriftDetail],
    missing: list[AnchorDriftDetail],
    model_spec: str,
    root: str,
    since: str,
) -> str:
    try:
        from patrol import call_llm
    except ImportError:
        return "(patrol.py not found — cannot generate narrative)"

    changed_files = git_log_files(root, since)

    def fmt_stale(d: AnchorDriftDetail) -> str:
        diff_preview = (d.diff or "")[:400].replace("\n", "\n  ")
        return f"- [{d.anchor_id}] {d.file}::{d.symbol or 'file'}\n  was: {d.description}\n  diff:\n  {diff_preview}"

    def fmt_missing(d: AnchorDriftDetail) -> str:
        cands = ", ".join(f"{c['file']}::{c['symbol']} ({c['similarity']})" for c in d.candidates[:3])
        return f"- [{d.anchor_id}] {d.file}::{d.symbol or 'file'}\n  was: {d.description}\n  candidates: {cands or 'none found'}"

    prompt = _NARRATIVE_PROMPT.format(
        stale_section="\n".join(fmt_stale(d) for d in stale) or "(none)",
        missing_section="\n".join(fmt_missing(d) for d in missing) or "(none)",
        changed_files="\n".join(changed_files[:20]) or "(no git info)",
    )

    try:
        return call_llm(prompt, model_spec, max_tokens=800)
    except Exception as e:
        return f"(narrative generation failed: {e})"


# ─────────────────────────────────────────────
# Action items builder
# ─────────────────────────────────────────────

def _build_action_items(
    stale: list[AnchorDriftDetail],
    missing: list[AnchorDriftDetail],
) -> list[dict]:
    items = []

    for d in stale:
        items.append({
            "priority": "medium",
            "action": "refresh_anchor",
            "anchor_id": d.anchor_id,
            "reason": f"Code changed. Run patrol.py or call refresh_anchor('{d.anchor_id}')",
        })

    for d in missing:
        if d.candidates:
            top = d.candidates[0]
            items.append({
                "priority": "high",
                "action": "rebind_anchor",
                "anchor_id": d.anchor_id,
                "reason": (
                    f"Symbol/file gone. Best candidate: {top['file']}::{top['symbol']} "
                    f"(similarity {top['similarity']}). "
                    f"Run: create_anchor('{d.anchor_id}', '{top['file']}', symbol='{top['symbol']}')"
                ),
                "suggested_rebind": {
                    "file": top["file"],
                    "symbol": top["symbol"],
                },
            })
        else:
            items.append({
                "priority": "high",
                "action": "manual_review",
                "anchor_id": d.anchor_id,
                "reason": f"Symbol/file gone, no candidates found. Functionality may have been deleted or split.",
            })

    return sorted(items, key=lambda x: {"high": 0, "medium": 1}.get(x["priority"], 2))


# ─────────────────────────────────────────────
# Markdown renderer
# ─────────────────────────────────────────────

def _render_markdown(
    stale: list[AnchorDriftDetail],
    missing: list[AnchorDriftDetail],
    narrative: str,
    action_items: list[dict],
    since: str,
) -> str:
    lines = [
        "# CodeAnchor Deep Drift Report",
        f"\n_Generated after refactor (comparing against `{since}`)_\n",
    ]

    if narrative:
        lines += ["\n## AI 变更叙述\n", narrative, ""]

    lines.append(f"\n## 需要处理的锚点 ({len(stale) + len(missing)} 个)\n")

    if missing:
        lines.append("### ✗ Missing（文件或符号已消失）\n")
        for d in missing:
            lines.append(f"#### `{d.anchor_id}`")
            lines.append(f"- **原路径**: `{d.file}` :: `{d.symbol or 'whole file'}`")
            lines.append(f"- **原描述**: {d.description}")
            if d.candidates:
                lines.append("- **模糊匹配候选**:")
                for c in d.candidates[:3]:
                    lines.append(f"  - `{c['file']}::{c['symbol']}` (相似度 {c['similarity']})")
            if d.old_source:
                lines.append(f"\n<details><summary>原代码片段</summary>\n\n```python\n{d.old_source[:600]}\n```\n</details>")
            lines.append("")

    if stale:
        lines.append("### ⚠ Stale（代码已改变）\n")
        for d in stale:
            lines.append(f"#### `{d.anchor_id}`")
            lines.append(f"- **路径**: `{d.file}` :: `{d.symbol or 'whole file'}`")
            lines.append(f"- **当前描述**: {d.description}")
            if d.diff:
                preview = "\n".join(d.diff.splitlines()[:30])
                lines.append(f"\n<details><summary>Diff 预览</summary>\n\n```diff\n{preview}\n```\n</details>")
            lines.append("")

    lines.append("\n## 行动清单\n")
    for item in action_items:
        priority_icon = "🔴" if item["priority"] == "high" else "🟡"
        lines.append(f"{priority_icon} **[{item['anchor_id']}]** {item['reason']}\n")

    return "\n".join(lines)


# ─────────────────────────────────────────────
# CLI
# ─────────────────────────────────────────────

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Deep drift analysis after large refactors")
    parser.add_argument("--root", default=".", help="Project root")
    parser.add_argument("--since", default="HEAD", help="Git ref to compare against (e.g. HEAD~3, main)")
    parser.add_argument("--model", default=None, help="LLM for narrative (e.g. ollama/qwen2.5-coder:7b)")
    parser.add_argument("--out", default="drift_report.md", help="Output markdown path")
    args = parser.parse_args()

    result = deep_drift_report(
        root=args.root,
        since=args.since,
        llm_model=args.model,
        output_md=args.out,
    )
    print(result["markdown"])
```
