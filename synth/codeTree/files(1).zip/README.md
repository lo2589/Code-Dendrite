# CodeAnchor

把文档描述绑定到具体代码片段的哈希。代码一变，锚点立即失效——agent 在干活前就能知道哪些文档在撒谎。

## 核心概念

```
# 文档里嵌入锚点 tag：
## 用户认证模块
<!-- @anchor{id="auth.validate" file="src/auth.py" symbol="AuthService.validate" hash="a3f2c1d8"} -->
负责验证 Bearer Token，失败超过3次后锁定账户...

# 代码变了 → hash 不匹配 → 报告 STALE → agent 知道文档过期
```

## 安装

```
code_anchor/
├── __init__.py
├── anchor_engine.py   # 核心逻辑
└── agent_tools.py     # agent tool registry
```

放进你的项目，直接 import。

## 接入你的 Copilot agent

```python
from code_anchor import TOOL_DEFINITIONS, handle_tool_call

# 1. 注册工具（Anthropic 格式，OpenAI 同理）
response = client.messages.create(
    model="claude-sonnet-4-20250514",
    tools=TOOL_DEFINITIONS,   # ← 直接传入
    messages=[...]
)

# 2. 处理工具调用
for block in response.content:
    if block.type == "tool_use":
        result = handle_tool_call(block.name, block.input)
        # 把 result 作为 tool_result 继续对话
```

## 四个工具

### `create_anchor` — 建立绑定
```python
# 绑定到函数级别（推荐）
create_anchor(
    anchor_id="auth.validate",
    file="src/auth/service.py",
    symbol="AuthService.validate",   # 或 "AuthService" 整个类，或 "validate" 裸函数
    description="验证 Bearer Token",
    root="/your/project"
)
# 返回：
# {
#   "status": "created",
#   "hash": "a3f2c1d8",
#   "tag": '@anchor{id="auth.validate" file="src/auth/service.py" ...}',
#   "instruction": "把这个 tag 粘贴到你的文档对应描述旁边"
# }

# 绑定到行范围
create_anchor("config.defaults", "config.py", line_start=10, line_end=25)

# 绑定整个文件
create_anchor("auth.module", "src/auth/service.py")
```

### `check_drift` — 检查漂移（每次 session 开始时调用）
```python
# 检查所有锚点
check_drift(root="/your/project")

# 检查特定锚点
check_drift(anchor_ids=["auth.validate", "db.models.User"])

# 直接扫描文档文本里的 @anchor tags
check_drift(doc_text=open("CLAUDE.md").read())

# 返回：
# {
#   "stale": [...],      # 代码变了，文档可能过期
#   "missing": [...],    # 文件/符号已删除或重命名
#   "ok": [...],
#   "all_valid": False,
#   "summary": "Drift check: 5 ok, 2 stale, 1 missing\n⚠ [auth.validate] ..."
# }
```

### `refresh_anchor` — 代码改完后更新哈希
```python
refresh_anchor("auth.validate", root="/your/project")
# 返回新的 tag，替换文档里的旧 tag
```

### `list_anchors` — 查看全部锚点状态
```python
list_anchors(root="/your/project")
```

## 推荐的 agent 工作流

在你的 agent system prompt 里加：

```
## 强制工作流

1. 每次 session 开始，首先调用 check_drift
2. 如果有 stale 锚点，先告知用户哪些文档描述可能失效，再继续
3. 完成代码修改后，调用 refresh_anchor 更新对应锚点
4. 写新功能的文档时，调用 create_anchor 建立绑定
```

## 锚点 DB

所有锚点存在 `.code_anchors.json`，建议加入版本控制：
```json
{
  "auth.validate": {
    "id": "auth.validate",
    "file": "src/auth/service.py",
    "symbol": "AuthService.validate",
    "hash": "a3f2c1d8",
    "description": "验证 Bearer Token"
  }
}
```

## 与你的代码树集成

你的代码树分析器生成摘要后，让 agent 自动为每个模块建锚点：

```python
# 你的代码树输出 → 批量建锚点
for module in code_tree.modules:
    create_anchor(
        anchor_id=module.dot_path,      # e.g. "auth.service.LoginHandler"
        file=module.file,
        symbol=module.symbol,
        description=module.summary,     # 你的代码树生成的摘要
        root=project_root
    )
```

之后每次 agent 读代码树摘要时，先 check_drift，
发现 stale 的部分就知道"这段摘要对应的代码已经改了，摘要可能不准"。
```
